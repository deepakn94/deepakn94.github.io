Teaching evaluations
====================

I am attaching teaching evaluations from 3 of the 5 courses I TAed as a Ph.D. student
at Stanford and M.Eng. student at MIT. Unfortunately, Stanford does not really have a culture
of evaluating courses, so the other two courses have too few reviews to be
meaningful.
