Sample course materials
=======================

As a Teaching Assistant, I taught courses that had been taught many times
before with a well-defined syllabus. I am attaching a few of the recitation
notes I helped write, as well as three programming assignments that I developed
from scratch.
