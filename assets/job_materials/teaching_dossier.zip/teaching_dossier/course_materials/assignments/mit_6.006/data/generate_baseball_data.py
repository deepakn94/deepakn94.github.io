import random


def parse_file(filename):
    with open(filename, 'r') as f:
        # Parse the text into a list of lists, with the outer list
        # corresponding to the list of players and each inner list
        # corresponding to the stats of that player
        lines = f.readlines()
        stats = [[token.strip() for token in line.split('\t')]
                 for line in lines[1:]]
        stat_header = [token.strip() for token in lines[0].split('\t')]
        stat_mapping = {
            stat_header[index].upper(): index
            for index in xrange(len(stat_header))}
        return stats, stat_mapping


def process_stats(stats, stat_mapping, imp_stats):
    return [{imp_stat.upper(): stat[stat_mapping[imp_stat.upper()]]
             for imp_stat in imp_stats} for stat in stats]


def dump_stats(stats, filename):
    with open(filename, 'w') as f:
        for stat in stats:
            f.write('%s\t%d\t%d\n' % (stat['PLAYER'], stat['H'], stat['RBI']))


def generate_stats_and_players(processed_stats):
    stats = []
    players = set()
    for processed_stat in processed_stats:
        avg = float(processed_stat['AVG'])
        num_abs = int(processed_stat['AB'])
        player = processed_stat['PLAYER']
        for i in xrange(num_abs):
            hit = 0
            rbi = 0
            if random.random() < avg:
                hit = 1
                rnd = random.random()
                if rnd < 0.8:
                    rbi = 0
                elif rnd < 0.95:
                    rbi = 1
                elif rnd < 0.99:
                    rbi = 2
                elif rnd < 0.995:
                    rbi = 3
                else:
                    rbi = 4
            stats.append({'H': hit, 'PLAYER': player, 'RBI': rbi})
            players.add(player)
    return stats, list(players)


def get_players(filename):
    players = list()
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            players.append(line)
    return players


def generate_stats_from_player_list(players):
    raw_stats = list()
    stats = list()
    for player in players:
        ab = 0
        while ab < 30 or ab > 700:
            ab = int(random.gauss(30, 300))
        avg = 0
        while avg < 100 or avg > 320:
            avg = random.gauss(260, 20)
        avg = float(avg) / 1000.0
        raw_stats.append((player, ab, avg))
    for stat in raw_stats:
        (player, num_abs, avg) = stat
        for i in xrange(num_abs):
            hit = 0
            rbi = 0
            if random.random() < avg:
                hit = 1
                rnd = random.random()
                if rnd < 0.8:
                    rbi = 0
                elif rnd < 0.95:
                    rbi = 1
                elif rnd < 0.99:
                    rbi = 2
                elif rnd < 0.995:
                    rbi = 3
                else:
                    rbi = 4
            stats.append({'H': hit, 'PLAYER': player, 'RBI': rbi})
    return stats


def generate_test_case(max_k, n, num_best, num_stat, players_stats, players):
    players_list = random.sample(players, n)
    player_set = set(players_list)
    max_k = min(max_k, n)
    processed_stats = [
        stat for stat in players_stats if stat['PLAYER'] in player_set]
    print players_list
    lines = list()
    for stat in processed_stats:
        lines.append('n\t%s\t%d\t%d' %
                     (stat['PLAYER'], stat['H'], stat['RBI']))
    stats_to_measure = ['avg', 'hits', 'rbi', 'ab']
    for i in xrange(num_best):
        stat = random.sample(stats_to_measure, 1)[0]
        k = random.randint(0, max_k)
        lines.append('cb\t%s\t%d' % (stat, k))
    for i in xrange(num_stat):
        player = random.sample(players_list, 1)[0]
        lines.append('cs\t%s' % player)
    random.shuffle(lines)
    with open('../implementation/driver_small4.txt', 'w') as f:
        f.write('\n'.join(lines))


if __name__ == '__main__':
    # imp_stats = ['Player', 'Avg', 'AB', 'H', ]
    # imp_mapping = {
    #     imp_stats[index].upper(): index for index in xrange(len(imp_stats))}
    # stats, stat_mapping = parse_file('baseball_stats.txt')
    # processed_stats = process_stats(stats, stat_mapping, imp_stats)
    # generated_stats, players = generate_stats_and_players(processed_stats)
    players = get_players('players.txt')
    generated_stats = generate_stats_from_player_list(players)
    random.shuffle(generated_stats)
    generate_test_case(10, 50, 200, 500, generated_stats, players)
    # dump_stats(generated_stats, 'processed_stats.txt')
