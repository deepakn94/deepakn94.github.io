def process_data_file(filename):
    player_names = list()
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            player_name = line.split('\t')[0]
            player_names.append(player_name)
    with open('processed_file.txt', 'w') as f:
        f.write('\n'.join(player_names))


if __name__ == '__main__':
    process_data_file('baseball_players.txt')
