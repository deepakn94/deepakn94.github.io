package memstore.data;

public class ByteFormat {
    public static int FIELD_LEN = 4;
}
