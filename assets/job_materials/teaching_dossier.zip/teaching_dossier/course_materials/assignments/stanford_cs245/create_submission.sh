rm student_submission.zip
zip -j student_submission.zip src/main/java/memstore/table/*.java