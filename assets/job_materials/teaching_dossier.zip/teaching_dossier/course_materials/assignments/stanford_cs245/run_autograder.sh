java -Xmx1328m -Xms500m -XX:-TieredCompilation -jar target/benchmarks.jar -m all -i 60 -ci 10
