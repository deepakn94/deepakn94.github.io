#!/bin/bash
for i in {1..100}
do
    ./runtasks mandelbrot_chunked
done
