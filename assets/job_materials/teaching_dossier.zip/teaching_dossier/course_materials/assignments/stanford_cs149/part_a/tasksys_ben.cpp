#include "tasksys.h"
#include <thread>
#include <stdio.h>
#include <condition_variable>
#include <iostream>


IRunnable::~IRunnable() {}

ITaskSystem::ITaskSystem(int num_threads) {}
ITaskSystem::~ITaskSystem() {}

const char* TaskSystemSerial::name() {
    return "Serial";
}

TaskSystemSerial::TaskSystemSerial(int num_threads): ITaskSystem(num_threads) {
}

TaskSystemSerial::~TaskSystemSerial() {}

void TaskSystemSerial::run(IRunnable* runnable, int num_total_tasks) {
    for (int i = 0; i < num_total_tasks; i++) {
        runnable->runTask(i, num_total_tasks);
    }
}

TaskID TaskSystemSerial::runAsyncWithDeps(IRunnable* runnable, int num_total_tasks,
                                          const std::vector<TaskID>& deps) {
    return 0;
}

void TaskSystemSerial::sync() {
    return;
}

const char* TaskSystemParallelSpawn::name() {
    return "Parallel + Always Spawn";
}

TaskSystemParallelSpawn::TaskSystemParallelSpawn(int num_threads): ITaskSystem(num_threads) {
    this->num_threads = num_threads;
}

TaskSystemParallelSpawn::~TaskSystemParallelSpawn() {}

void TaskSystemParallelSpawn::run(IRunnable* runnable, int num_total_tasks) {
    std::thread* threads = new std::thread[this->num_threads];

    for (int i = 0; i < this->num_threads; i++) {
      threads[i] = std::thread(&TaskSystemParallelSpawn::runThreadTasks, this, runnable, num_total_tasks, i);
    }

    for (int i = 0; i < this->num_threads; i++) {
        threads[i].join();
    }
}

void TaskSystemParallelSpawn::runThreadTasks(IRunnable* runnable, int num_total_tasks, int idx) {
  for (int i = idx; i < num_total_tasks; i += this->num_threads) {
    runnable->runTask(i, num_total_tasks);
  }
}


TaskID TaskSystemParallelSpawn::runAsyncWithDeps(IRunnable* runnable, int num_total_tasks,
                                                 const std::vector<TaskID>& deps) {
    return 0;
}

void TaskSystemParallelSpawn::sync() {
    return;
}

const char* TaskSystemParallelThreadPoolSpinning::name() {
    return "Parallel + Thread Pool + Spin";
}

TaskSystemParallelThreadPoolSpinning::TaskSystemParallelThreadPoolSpinning(int num_threads): ITaskSystem(num_threads) {
    this->threadsFinishedCurrentTask = new bool[num_threads];
    for (int i = 0; i < num_threads; i++) {
      this->threadsFinishedCurrentTask[i] = true;
    }
    this->currentTasksComplete_mutex = new std::mutex();

    this->cv = new std::condition_variable();
    this->num_threads = num_threads;

    this->allTasksComplete = false;
    this->threads = new std::thread[num_threads];

    this->num_total_tasks = 0;
    this->task_idx = 0;
    this->task_idx_mutex = new std::mutex();

    for (int i = 0; i < num_threads; i++) {
        threads[i] = std::thread(&TaskSystemParallelThreadPoolSpinning::spin, this, i);
    }
}

bool TaskSystemParallelThreadPoolSpinning::threadsFinished() {
  for (int i = 0; i < this->num_threads; i++) {
    if (!this->threadsFinishedCurrentTask[i]) return false;
  }
  return true;
}

void TaskSystemParallelThreadPoolSpinning::spin(int threadIdx) {
  while(!allTasksComplete) {
    this->task_idx_mutex->lock();
    int task_id = task_idx;
    if (task_idx < num_total_tasks) {
      this->task_idx++;
    }
    this->task_idx_mutex->unlock();

    if (task_id < num_total_tasks) {
      this->currentRunnable->runTask(task_id, num_total_tasks);
    } else {
      this->threadsFinishedCurrentTask[threadIdx] = true;
      this->task_idx_mutex->lock();

      if (threadsFinished()) cv->notify_all(); // May not finish run(), but worth checking in case this is last thread
      this->task_idx_mutex->unlock();

    }
  }
}

TaskSystemParallelThreadPoolSpinning::~TaskSystemParallelThreadPoolSpinning() {
  this->task_idx_mutex->lock();
  allTasksComplete = true;
  this->task_idx_mutex->unlock();

  for (int i = 0; i < num_threads; i++) {
      threads[i].join();
  }

  delete threadsFinishedCurrentTask;
  delete[] threads;
  delete task_idx_mutex;
  delete cv;
  delete currentTasksComplete_mutex;
}

void TaskSystemParallelThreadPoolSpinning::run(IRunnable* runnable, int num_total_tasks) {
  this->task_idx_mutex->lock(); // Threads: freeze all motor functions!
  for (int i = 0; i < num_threads; i++) {
    this->threadsFinishedCurrentTask[i] = false;
  }
  this->currentRunnable = runnable;
  this->task_idx = 0;
  this->num_total_tasks = num_total_tasks;
  this->task_idx_mutex->unlock(); // Threads: Ok do ur work now

  std::unique_lock<std::mutex> lk(*currentTasksComplete_mutex);
  cv->wait(lk, [this]{return threadsFinished();});
}

TaskID TaskSystemParallelThreadPoolSpinning::runAsyncWithDeps(IRunnable* runnable, int num_total_tasks,
                                                              const std::vector<TaskID>& deps) {
    return 0;
}

void TaskSystemParallelThreadPoolSpinning::sync() {
    return;
}


const char* TaskSystemParallelThreadPoolSleeping::name() {
    return "Parallel + Thread Pool + Sleep";
}

TaskSystemParallelThreadPoolSleeping::TaskSystemParallelThreadPoolSleeping(int num_threads): ITaskSystem(num_threads) {
  this->num_threads = num_threads;
  this->num_total_tasks = 0;
  this->next_task_idx = 0;
  this->num_tasks_completed = 0;
  this->thread_state_mutex = new std::mutex();
  //this->thread_state_mutex->lock();
  this->all_tasks_complete = false;
  //this->thread_state_mutex->unlock();
  this->worker_cv = new std::condition_variable();
  this->dispatcher_cv = new std::condition_variable();
  this->threads = new std::thread[num_threads];
  for (int i = 0; i < num_threads; i++) {
    threads[i] = std::thread(&TaskSystemParallelThreadPoolSleeping::handleThread, this);
  }
}

void TaskSystemParallelThreadPoolSleeping::handleThread() {
  std::unique_lock<std::mutex> lk(*thread_state_mutex);
  while (!all_tasks_complete) {
    int task_id_todo = next_task_idx;
    if (task_id_todo < num_total_tasks) {
     next_task_idx++;
      lk.unlock();
      this->current_runnable->runTask(task_id_todo, num_total_tasks);
      lk.lock();
      num_tasks_completed++;
    } else {
      if (num_tasks_completed >= num_total_tasks) {
        dispatcher_cv->notify_all();
      }
      if (!all_tasks_complete) worker_cv->wait(lk);
    }
  }
}

TaskSystemParallelThreadPoolSleeping::~TaskSystemParallelThreadPoolSleeping() {
  //this->thread_state_mutex->lock();
  all_tasks_complete = true;
  //this->thread_state_mutex->unlock();
  worker_cv->notify_all();

  for (int i = 0; i < num_threads; i++) {
      threads[i].join();
  }

  delete thread_state_mutex;
  delete worker_cv;
  delete dispatcher_cv;
  delete[] threads;
}

void TaskSystemParallelThreadPoolSleeping::run(IRunnable* runnable, int num_total_tasks) {
  //return;
  thread_state_mutex->lock();
  this->num_total_tasks = num_total_tasks;
  this->next_task_idx = 0;
  this->num_tasks_completed = 0;
  this->current_runnable = runnable;
  thread_state_mutex->unlock();

  worker_cv->notify_all();
  std::unique_lock<std::mutex> lk(*thread_state_mutex);
  dispatcher_cv->wait(lk, [this]{
    return this->num_tasks_completed >= this->num_total_tasks;
  });
}

TaskID TaskSystemParallelThreadPoolSleeping::runAsyncWithDeps(IRunnable* runnable, int num_total_tasks,
                                                    const std::vector<TaskID>& deps) {


    //
    // TODO: CS149 students will implement this method in Part B.
    //

    return 0;
}

void TaskSystemParallelThreadPoolSleeping::sync() {

    //
    // TODO: CS149 students will modify the implementation of this method in Part B.
    //

    return;
}
